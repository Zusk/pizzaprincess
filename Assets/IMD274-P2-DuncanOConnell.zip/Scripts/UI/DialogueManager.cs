﻿using UnityEngine;
using System.Collections.Generic; // Needed for using List
using System.Linq;

public class DialogueManager : MonoBehaviour
{
    public List<MonoBehaviour> scriptsToDisable; // Assign your scripts here in the inspector
    public GameObject dialogueObject; // Assign your dialogue GameObject here in the inspector

    private bool isDialogueActive = false;
    public static bool inDialogue = false;

    public float interactionRadius = 0.1f; // Interaction radius for detecting NPCs

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            TryStartDialogue();
        }
    }

    private void TryStartDialogue()
    {
        Collider[] hitColliders = Physics.OverlapSphere(transform.position, interactionRadius);
        List<TalkableNPC> npcsInRange = new List<TalkableNPC>();

        foreach (var hitCollider in hitColliders)
        {
            TalkableNPC npc = hitCollider.GetComponent<TalkableNPC>();
            if (npc != null)
            {
                npcsInRange.Add(npc);
            }
        }

        if (npcsInRange.Count > 0)
        {
            int randomIndex = Random.Range(0, npcsInRange.Count);
            TalkableNPC selectedNPC = npcsInRange[randomIndex];

            if (selectedNPC.startingConversation.Count > 0)
            {
                object[] conversationItems = new object[selectedNPC.startingConversation.Count];
                for (int i = 0; i < selectedNPC.startingConversation.Count; i++)
                {
                    conversationItems[i] = selectedNPC.startingConversation[i];
                }

                EnterDialogue(conversationItems);
            }
        }
    }

    public void EnterDialogue(object[] items)
    {
        if(PauseManager.isPaused){
            return;
        }
        ToggleDialogue();

        // Assuming ButtonManager is part of the dialogueObject
        if (dialogueObject != null)
        {
            ButtonManager buttonManager = dialogueObject.GetComponent<ButtonManager>();
            if (buttonManager != null)
            {
                buttonManager.BuildButtonMenu(items);
            }
        }
    }

    public void ToggleDialogue()
    {
        isDialogueActive = !isDialogueActive;
        inDialogue = isDialogueActive; // Update the inDialogue static variable

        // Toggle mouse visibility and locking
        Cursor.lockState = isDialogueActive ? CursorLockMode.None : CursorLockMode.Locked;
        Cursor.visible = isDialogueActive;

        // Enable or disable the list of scripts
        if (scriptsToDisable != null)
        {
            foreach (MonoBehaviour script in scriptsToDisable)
            {
                if (script != null)
                {
                    script.enabled = !isDialogueActive;
                }
            }
        }

        // Enable or disable the dialogue object
        if (dialogueObject != null)
        {
            dialogueObject.SetActive(isDialogueActive);

            // If the dialogue is being opened, build its button menu
            if (isDialogueActive)
            {
                ButtonManager buttonManager = dialogueObject.GetComponent<ButtonManager>();
                if (buttonManager != null)
                {
                    buttonManager.BuildButtonMenu(new object[] { ButtonType.Dialogue_1_Topic_Label, ButtonType.Dialogue_1_Option_1 });
                }
            }
        }

        // Set the time scale to 0 if dialogue is active, or 1 if not
        Time.timeScale = isDialogueActive ? 0 : 1;
    }

}
